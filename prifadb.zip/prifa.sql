-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2019 at 03:12 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prifa`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` text NOT NULL,
  `phone` varchar(50) NOT NULL,
  `admin_type` varchar(50) NOT NULL,
  `num` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `regdate` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `phone`, `admin_type`, `num`, `status`, `regdate`) VALUES
(1, 'Administrator', 'admin@prifa.com.ng', '$2y$10$WjLI9.F.bh375vSXK0XxpunE3ILrvmhAChfxqe77cUqt7b74rt0Ry', '08062165573', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `adm_message`
--

CREATE TABLE `adm_message` (
  `id` int(11) NOT NULL,
  `subject` text NOT NULL,
  `name` varchar(200) NOT NULL,
  `msg` text NOT NULL,
  `user_code` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `msg_date` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `num` varchar(10) NOT NULL,
  `msg_code` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adm_message`
--

INSERT INTO `adm_message` (`id`, `subject`, `name`, `msg`, `user_code`, `email`, `msg_date`, `status`, `num`, `msg_code`) VALUES
(1, '', 'Administrator007', '', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:30:18 PM', '0', '1', ''),
(2, '', 'Crespy Edo', '', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:33:52 PM', '0', '1', '905866'),
(3, '', 'EMETULU@YAHOO.COM', '', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:37:35 PM', '0', '1', '292859'),
(4, '', 'Victoria paul', '', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:41:17 PM', '0', '1', '927739'),
(5, '', 'sophia@yahoo.com', '', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:47:13 PM', '0', '1', '553079'),
(6, '', 'jss1a@yahoo.com', 'g87tfg7g66g', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:49:23 PM', '0', '1', '747298'),
(7, '', 'Aboajah Emmanuel ike', 'fdhdjcjcjccj', '5c18f0efc8857', 'ciwmnig@gmail.com', '22nd  December 2018 07:09:17 AM', '0', '1', '120295'),
(8, '', 'jss1a@yahoo.com', 'gfcyygh', '5c18f0efc8857', 'ciwmnig@gmail.com', '22nd  December 2018 07:53:12 AM', '0', '1', '231571');

-- --------------------------------------------------------

--
-- Table structure for table `google_users`
--

CREATE TABLE `google_users` (
  `google_id` int(12) NOT NULL,
  `clint_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `google_email` varchar(60) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `picture_link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `imgtest`
--

CREATE TABLE `imgtest` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `imgtest`
--

INSERT INTO `imgtest` (`id`, `name`) VALUES
(33, 'banner-03.jpg'),
(34, 'color.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `locals`
--

CREATE TABLE `locals` (
  `local_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `local_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locals`
--

INSERT INTO `locals` (`local_id`, `state_id`, `local_name`) VALUES
(1, 1, 'Aba South'),
(2, 1, 'Arochukwu'),
(3, 1, 'Bende'),
(4, 1, 'Ikwuano'),
(5, 1, 'Isiala Ngwa North'),
(6, 1, 'Isiala Ngwa South'),
(7, 1, 'Isuikwuato'),
(8, 1, 'Obi Ngwa'),
(9, 1, 'Ohafia'),
(10, 1, 'Osisioma'),
(11, 1, 'Ugwunagbo'),
(12, 1, 'Ukwa East'),
(13, 1, 'Ukwa West'),
(14, 1, 'Umuahia North'),
(15, 1, 'Umuahia South'),
(16, 1, 'Umu Nneochi'),
(17, 2, 'Fufure'),
(18, 2, 'Ganye'),
(19, 2, 'Gayuk'),
(20, 2, 'Gombi'),
(21, 2, 'Grie'),
(22, 2, 'Hong'),
(23, 2, 'Jada'),
(24, 2, 'Lamurde'),
(25, 2, 'Madagali'),
(26, 2, 'Maiha'),
(27, 2, 'Mayo Belwa'),
(28, 2, 'Michika'),
(29, 2, 'Mubi North'),
(30, 2, 'Mubi South'),
(31, 2, 'Numan'),
(32, 2, 'Shelleng'),
(33, 2, 'Song'),
(34, 2, 'Toungo'),
(35, 2, 'Yola North'),
(36, 2, 'Yola South'),
(37, 3, 'Eastern Obolo'),
(38, 3, 'Eket'),
(39, 3, 'Esit Eket'),
(40, 3, 'Essien Udim'),
(41, 3, 'Etim Ekpo'),
(42, 3, 'Etinan'),
(43, 3, 'Ibeno'),
(44, 3, 'Ibesikpo Asutan'),
(45, 3, 'Ibiono-Ibom'),
(46, 3, 'Ika'),
(47, 3, 'Ikono'),
(48, 3, 'Ikot Abasi'),
(49, 3, 'Ikot Ekpene'),
(50, 3, 'Ini'),
(51, 3, 'Itu'),
(52, 3, 'Mbo'),
(53, 3, 'Mkpat-Enin'),
(54, 3, 'Nsit-Atai'),
(55, 3, 'Nsit-Ibom'),
(56, 3, 'Nsit-Ubium'),
(57, 3, 'Obot Akara'),
(58, 3, 'Okobo'),
(59, 3, 'Onna'),
(60, 3, 'Oron'),
(61, 3, 'Oruk Anam'),
(62, 3, 'Udung-Uko'),
(63, 3, 'Ukanafun'),
(64, 3, 'Uruan'),
(65, 3, 'Urue-Offong/Oruko'),
(66, 3, 'Uyo'),
(67, 4, 'Anambra East'),
(68, 4, 'Anambra West'),
(69, 4, 'Anaocha'),
(70, 4, 'Awka North'),
(71, 4, 'Awka South'),
(72, 4, 'Ayamelum'),
(73, 4, 'Dunukofia'),
(74, 4, 'Ekwusigo'),
(75, 4, 'Idemili North'),
(76, 4, 'Idemili South'),
(77, 4, 'Ihiala'),
(78, 4, 'Njikoka'),
(79, 4, 'Nnewi North'),
(80, 4, 'Nnewi South'),
(81, 4, 'Ogbaru'),
(82, 4, 'Onitsha North'),
(83, 4, 'Onitsha South'),
(84, 4, 'Orumba North'),
(85, 4, 'Orumba South'),
(86, 4, 'Oyi'),
(87, 5, 'Bauchi'),
(88, 5, 'Bogoro'),
(89, 5, 'Damban'),
(90, 5, 'Darazo'),
(91, 5, 'Dass'),
(92, 5, 'Gamawa'),
(93, 5, 'Ganjuwa'),
(94, 5, 'Giade'),
(95, 5, 'Itas/Gadau'),
(96, 5, 'Jama\'are'),
(97, 5, 'Katagum'),
(98, 5, 'Kirfi'),
(99, 5, 'Misau'),
(100, 5, 'Ningi'),
(101, 5, 'Shira'),
(102, 5, 'Tafawa Balewa'),
(103, 5, 'Toro'),
(104, 5, 'Warji'),
(105, 5, 'Zaki'),
(106, 6, 'Ekeremor'),
(107, 6, 'Kolokuma/Opokuma'),
(108, 6, 'Nembe'),
(109, 6, 'Ogbia'),
(110, 6, 'Sagbama'),
(111, 6, 'Southern Ijaw'),
(112, 6, 'Yenagoa'),
(113, 7, 'Apa'),
(114, 7, 'Ado'),
(115, 7, 'Buruku'),
(116, 7, 'Gboko'),
(117, 7, 'Guma'),
(118, 7, 'Gwer East'),
(119, 7, 'Gwer West'),
(120, 7, 'Katsina-Ala'),
(121, 7, 'Konshisha'),
(122, 7, 'Kwande'),
(123, 7, 'Logo'),
(124, 7, 'Makurdi'),
(125, 7, 'Obi'),
(126, 7, 'Ogbadibo'),
(127, 7, 'Ohimini'),
(128, 7, 'Oju'),
(129, 7, 'Okpokwu'),
(130, 7, 'Oturkpo'),
(131, 7, 'Tarka'),
(132, 7, 'Ukum'),
(133, 7, 'Ushongo'),
(134, 7, 'Vandeikya'),
(135, 8, 'Askira/Uba'),
(136, 8, 'Bama'),
(137, 8, 'Bayo'),
(138, 8, 'Biu'),
(139, 8, 'Chibok'),
(140, 8, 'Damboa'),
(141, 8, 'Dikwa'),
(142, 8, 'Gubio'),
(143, 8, 'Guzamala'),
(144, 8, 'Gwoza'),
(145, 8, 'Hawul'),
(146, 8, 'Jere'),
(147, 8, 'Kaga'),
(148, 8, 'Kala/Balge'),
(149, 8, 'Konduga'),
(150, 8, 'Kukawa'),
(151, 8, 'Kwaya Kusar'),
(152, 8, 'Mafa'),
(153, 8, 'Magumeri'),
(154, 8, 'Maiduguri'),
(155, 8, 'Marte'),
(156, 8, 'Mobbar'),
(157, 8, 'Monguno'),
(158, 8, 'Ngala'),
(159, 8, 'Nganzai'),
(160, 8, 'Shani'),
(161, 9, 'Akamkpa'),
(162, 9, 'Akpabuyo'),
(163, 9, 'Bakassi'),
(164, 9, 'Bekwarra'),
(165, 9, 'Biase'),
(166, 9, 'Boki'),
(167, 9, 'Calabar Municipal'),
(168, 9, 'Calabar South'),
(169, 9, 'Etung'),
(170, 9, 'Ikom'),
(171, 9, 'Obanliku'),
(172, 9, 'Obubra'),
(173, 9, 'Obudu'),
(174, 9, 'Odukpani'),
(175, 9, 'Ogoja'),
(176, 9, 'Yakuur'),
(177, 9, 'Yala'),
(178, 10, 'Aniocha South'),
(179, 10, 'Bomadi'),
(180, 10, 'Burutu'),
(181, 10, 'Ethiope East'),
(182, 10, 'Ethiope West'),
(183, 10, 'Ika North East'),
(184, 10, 'Ika South'),
(185, 10, 'Isoko North'),
(186, 10, 'Isoko South'),
(187, 10, 'Ndokwa East'),
(188, 10, 'Ndokwa West'),
(189, 10, 'Okpe'),
(190, 10, 'Oshimili North'),
(191, 10, 'Oshimili South'),
(192, 10, 'Patani'),
(193, 10, 'Sapele'),
(194, 10, 'Udu'),
(195, 10, 'Ughelli North'),
(196, 10, 'Ughelli South'),
(197, 10, 'Ukwuani'),
(198, 10, 'Uvwie'),
(199, 10, 'Warri North'),
(200, 10, 'Warri South'),
(201, 10, 'Warri South West'),
(202, 11, 'Afikpo North'),
(203, 11, 'Afikpo South'),
(204, 11, 'Ebonyi'),
(205, 11, 'Ezza North'),
(206, 11, 'Ezza South'),
(207, 11, 'Ikwo'),
(208, 11, 'Ishielu'),
(209, 11, 'Ivo'),
(210, 11, 'Izzi'),
(211, 11, 'Ohaozara'),
(212, 11, 'Ohaukwu'),
(213, 11, 'Onicha'),
(214, 12, 'Egor'),
(215, 12, 'Esan Central'),
(216, 12, 'Esan North-East'),
(217, 12, 'Esan South-East'),
(218, 12, 'Esan West'),
(219, 12, 'Etsako Central'),
(220, 12, 'Etsako East'),
(221, 12, 'Etsako West'),
(222, 12, 'Igueben'),
(223, 12, 'Ikpoba Okha'),
(224, 12, 'Orhionmwon'),
(225, 12, 'Oredo'),
(226, 12, 'Ovia North-East'),
(227, 12, 'Ovia South-West'),
(228, 12, 'Owan East'),
(229, 12, 'Owan West'),
(230, 12, 'Uhunmwonde'),
(231, 13, 'Efon'),
(232, 13, 'Ekiti East'),
(233, 13, 'Ekiti South-West'),
(234, 13, 'Ekiti West'),
(235, 13, 'Emure'),
(236, 13, 'Gbonyin'),
(237, 13, 'Ido Osi'),
(238, 13, 'Ijero'),
(239, 13, 'Ikere'),
(240, 13, 'Ikole'),
(241, 13, 'Ilejemeje'),
(242, 13, 'Irepodun/Ifelodun'),
(243, 13, 'Ise/Orun'),
(244, 13, 'Moba'),
(245, 13, 'Oye'),
(246, 14, 'Awgu'),
(247, 14, 'Enugu East'),
(248, 14, 'Enugu North'),
(249, 14, 'Enugu South'),
(250, 14, 'Ezeagu'),
(251, 14, 'Igbo Etiti'),
(252, 14, 'Igbo Eze North'),
(253, 14, 'Igbo Eze South'),
(254, 14, 'Isi Uzo'),
(255, 14, 'Nkanu East'),
(256, 14, 'Nkanu West'),
(257, 14, 'Nsukka'),
(258, 14, 'Oji River'),
(259, 14, 'Udenu'),
(260, 14, 'Udi'),
(261, 14, 'Uzo Uwani'),
(262, 15, 'Bwari'),
(263, 15, 'Gwagwalada'),
(264, 15, 'Kuje'),
(265, 15, 'Kwali'),
(266, 15, 'Municipal Area Council'),
(267, 16, 'Balanga'),
(268, 16, 'Billiri'),
(269, 16, 'Dukku'),
(270, 16, 'Funakaye'),
(271, 16, 'Gombe'),
(272, 16, 'Kaltungo'),
(273, 16, 'Kwami'),
(274, 16, 'Nafada'),
(275, 16, 'Shongom'),
(276, 16, 'Yamaltu/Deba'),
(277, 17, 'Ahiazu Mbaise'),
(278, 17, 'Ehime Mbano'),
(279, 17, 'Ezinihitte'),
(280, 17, 'Ideato North'),
(281, 17, 'Ideato South'),
(282, 17, 'Ihitte/Uboma'),
(283, 17, 'Ikeduru'),
(284, 17, 'Isiala Mbano'),
(285, 17, 'Isu'),
(286, 17, 'Mbaitoli'),
(287, 17, 'Ngor Okpala'),
(288, 17, 'Njaba'),
(289, 17, 'Nkwerre'),
(290, 17, 'Nwangele'),
(291, 17, 'Obowo'),
(292, 17, 'Oguta'),
(293, 17, 'Ohaji/Egbema'),
(294, 17, 'Okigwe'),
(295, 17, 'Orlu'),
(296, 17, 'Orsu'),
(297, 17, 'Oru East'),
(298, 17, 'Oru West'),
(299, 17, 'Owerri Municipal'),
(300, 17, 'Owerri North'),
(301, 17, 'Owerri West'),
(302, 17, 'Unuimo'),
(303, 18, 'Babura'),
(304, 18, 'Biriniwa'),
(305, 18, 'Birnin Kudu'),
(306, 18, 'Buji'),
(307, 18, 'Dutse'),
(308, 18, 'Gagarawa'),
(309, 18, 'Garki'),
(310, 18, 'Gumel'),
(311, 18, 'Guri'),
(312, 18, 'Gwaram'),
(313, 18, 'Gwiwa'),
(314, 18, 'Hadejia'),
(315, 18, 'Jahun'),
(316, 18, 'Kafin Hausa'),
(317, 18, 'Kazaure'),
(318, 18, 'Kiri Kasama'),
(319, 18, 'Kiyawa'),
(320, 18, 'Kaugama'),
(321, 18, 'Maigatari'),
(322, 18, 'Malam Madori'),
(323, 18, 'Miga'),
(324, 18, 'Ringim'),
(325, 18, 'Roni'),
(326, 18, 'Sule Tankarkar'),
(327, 18, 'Taura'),
(328, 18, 'Yankwashi'),
(329, 19, 'Chikun'),
(330, 19, 'Giwa'),
(331, 19, 'Igabi'),
(332, 19, 'Ikara'),
(333, 19, 'Jaba'),
(334, 19, 'Jema\'a'),
(335, 19, 'Kachia'),
(336, 19, 'Kaduna North'),
(337, 19, 'Kaduna South'),
(338, 19, 'Kagarko'),
(339, 19, 'Kajuru'),
(340, 19, 'Kaura'),
(341, 19, 'Kauru'),
(342, 19, 'Kubau'),
(343, 19, 'Kudan'),
(344, 19, 'Lere'),
(345, 19, 'Makarfi'),
(346, 19, 'Sabon Gari'),
(347, 19, 'Sanga'),
(348, 19, 'Soba'),
(349, 19, 'Zangon Kataf'),
(350, 19, 'Zaria'),
(351, 20, 'Albasu'),
(352, 20, 'Bagwai'),
(353, 20, 'Bebeji'),
(354, 20, 'Bichi'),
(355, 20, 'Bunkure'),
(356, 20, 'Dala'),
(357, 20, 'Dambatta'),
(358, 20, 'Dawakin Kudu'),
(359, 20, 'Dawakin Tofa'),
(360, 20, 'Doguwa'),
(361, 20, 'Fagge'),
(362, 20, 'Gabasawa'),
(363, 20, 'Garko'),
(364, 20, 'Garun Mallam'),
(365, 20, 'Gaya'),
(366, 20, 'Gezawa'),
(367, 20, 'Gwale'),
(368, 20, 'Gwarzo'),
(369, 20, 'Kabo'),
(370, 20, 'Kano Municipal'),
(371, 20, 'Karaye'),
(372, 20, 'Kibiya'),
(373, 20, 'Kiru'),
(374, 20, 'Kumbotso'),
(375, 20, 'Kunchi'),
(376, 20, 'Kura'),
(377, 20, 'Madobi'),
(378, 20, 'Makoda'),
(379, 20, 'Minjibir'),
(380, 20, 'Nasarawa'),
(381, 20, 'Rano'),
(382, 20, 'Rimin Gado'),
(383, 20, 'Rogo'),
(384, 20, 'Shanono'),
(385, 20, 'Sumaila'),
(386, 20, 'Takai'),
(387, 20, 'Tarauni'),
(388, 20, 'Tofa'),
(389, 20, 'Tsanyawa'),
(390, 20, 'Tudun Wada'),
(391, 20, 'Ungogo'),
(392, 20, 'Warawa'),
(393, 20, 'Wudil'),
(394, 21, 'Batagarawa'),
(395, 21, 'Batsari'),
(396, 21, 'Baure'),
(397, 21, 'Bindawa'),
(398, 21, 'Charanchi'),
(399, 21, 'Dandume'),
(400, 21, 'Danja'),
(401, 21, 'Dan Musa'),
(402, 21, 'Daura'),
(403, 21, 'Dutsi'),
(404, 21, 'Dutsin Ma'),
(405, 21, 'Faskari'),
(406, 21, 'Funtua'),
(407, 21, 'Ingawa'),
(408, 21, 'Jibia'),
(409, 21, 'Kafur'),
(410, 21, 'Kaita'),
(411, 21, 'Kankara'),
(412, 21, 'Kankia'),
(413, 21, 'Katsina'),
(414, 21, 'Kurfi'),
(415, 21, 'Kusada'),
(416, 21, 'Mai\'Adua'),
(417, 21, 'Malumfashi'),
(418, 21, 'Mani'),
(419, 21, 'Mashi'),
(420, 21, 'Matazu'),
(421, 21, 'Musawa'),
(422, 21, 'Rimi'),
(423, 21, 'Sabuwa'),
(424, 21, 'Safana'),
(425, 21, 'Sandamu'),
(426, 21, 'Zango'),
(427, 22, 'Arewa Dandi'),
(428, 22, 'Argungu'),
(429, 22, 'Augie'),
(430, 22, 'Bagudo'),
(431, 22, 'Birnin Kebbi'),
(432, 22, 'Bunza'),
(433, 22, 'Dandi'),
(434, 22, 'Fakai'),
(435, 22, 'Gwandu'),
(436, 22, 'Jega'),
(437, 22, 'Kalgo'),
(438, 22, 'Koko/Besse'),
(439, 22, 'Maiyama'),
(440, 22, 'Ngaski'),
(441, 22, 'Sakaba'),
(442, 22, 'Shanga'),
(443, 22, 'Suru'),
(444, 22, 'Wasagu/Danko'),
(445, 22, 'Yauri'),
(446, 22, 'Zuru'),
(447, 23, 'Ajaokuta'),
(448, 23, 'Ankpa'),
(449, 23, 'Bassa'),
(450, 23, 'Dekina'),
(451, 23, 'Ibaji'),
(452, 23, 'Idah'),
(453, 23, 'Igalamela Odolu'),
(454, 23, 'Ijumu'),
(455, 23, 'Kabba/Bunu'),
(456, 23, 'Kogi'),
(457, 23, 'Lokoja'),
(458, 23, 'Mopa Muro'),
(459, 23, 'Ofu'),
(460, 23, 'Ogori/Magongo'),
(461, 23, 'Okehi'),
(462, 23, 'Okene'),
(463, 23, 'Olamaboro'),
(464, 23, 'Omala'),
(465, 23, 'Yagba East'),
(466, 23, 'Yagba West'),
(467, 24, 'Baruten'),
(468, 24, 'Edu'),
(469, 24, 'Ekiti'),
(470, 24, 'Ifelodun'),
(471, 24, 'Ilorin East'),
(472, 24, 'Ilorin South'),
(473, 24, 'Ilorin West'),
(474, 24, 'Irepodun'),
(475, 24, 'Isin'),
(476, 24, 'Kaiama'),
(477, 24, 'Moro'),
(478, 24, 'Offa'),
(479, 24, 'Oke Ero'),
(480, 24, 'Oyun'),
(481, 24, 'Pategi'),
(482, 25, 'Ajeromi-Ifelodun'),
(483, 25, 'Alimosho'),
(484, 25, 'Amuwo-Odofin'),
(485, 25, 'Apapa'),
(486, 25, 'Badagry'),
(487, 25, 'Epe'),
(488, 25, 'Eti Osa'),
(489, 25, 'Ibeju-Lekki'),
(490, 25, 'Ifako-Ijaiye'),
(491, 25, 'Ikeja'),
(492, 25, 'Ikorodu'),
(493, 25, 'Kosofe'),
(494, 25, 'Lagos Island'),
(495, 25, 'Lagos Mainland'),
(496, 25, 'Mushin'),
(497, 25, 'Ojo'),
(498, 25, 'Oshodi-Isolo'),
(499, 25, 'Shomolu'),
(500, 25, 'Surulere'),
(501, 26, 'Awe'),
(502, 26, 'Doma'),
(503, 26, 'Karu'),
(504, 26, 'Keana'),
(505, 26, 'Keffi'),
(506, 26, 'Kokona'),
(507, 26, 'Lafia'),
(508, 26, 'Nasarawa'),
(509, 26, 'Nasarawa Egon'),
(510, 26, 'Obi'),
(511, 26, 'Toto'),
(512, 26, 'Wamba'),
(513, 27, 'Agwara'),
(514, 27, 'Bida'),
(515, 27, 'Borgu'),
(516, 27, 'Bosso'),
(517, 27, 'Chanchaga'),
(518, 27, 'Edati'),
(519, 27, 'Gbako'),
(520, 27, 'Gurara'),
(521, 27, 'Katcha'),
(522, 27, 'Kontagora'),
(523, 27, 'Lapai'),
(524, 27, 'Lavun'),
(525, 27, 'Magama'),
(526, 27, 'Mariga'),
(527, 27, 'Mashegu'),
(528, 27, 'Mokwa'),
(529, 27, 'Moya'),
(530, 27, 'Paikoro'),
(531, 27, 'Rafi'),
(532, 27, 'Rijau'),
(533, 27, 'Shiroro'),
(534, 27, 'Suleja'),
(535, 27, 'Tafa'),
(536, 27, 'Wushishi'),
(537, 28, 'Abeokuta South'),
(538, 28, 'Ado-Odo/Ota'),
(539, 28, 'Egbado North'),
(540, 28, 'Egbado South'),
(541, 28, 'Ewekoro'),
(542, 28, 'Ifo'),
(543, 28, 'Ijebu East'),
(544, 28, 'Ijebu North'),
(545, 28, 'Ijebu North East'),
(546, 28, 'Ijebu Ode'),
(547, 28, 'Ikenne'),
(548, 28, 'Imeko Afon'),
(549, 28, 'Ipokia'),
(550, 28, 'Obafemi Owode'),
(551, 28, 'Odeda'),
(552, 28, 'Odogbolu'),
(553, 28, 'Ogun Waterside'),
(554, 28, 'Remo North'),
(555, 28, 'Shagamu'),
(556, 29, 'Akoko North-West'),
(557, 29, 'Akoko South-West'),
(558, 29, 'Akoko South-East'),
(559, 29, 'Akure North'),
(560, 29, 'Akure South'),
(561, 29, 'Ese Odo'),
(562, 29, 'Idanre'),
(563, 29, 'Ifedore'),
(564, 29, 'Ilaje'),
(565, 29, 'Ile Oluji/Okeigbo'),
(566, 29, 'Irele'),
(567, 29, 'Odigbo'),
(568, 29, 'Okitipupa'),
(569, 29, 'Ondo East'),
(570, 29, 'Ondo West'),
(571, 29, 'Ose'),
(572, 29, 'Owo'),
(573, 30, 'Atakunmosa West'),
(574, 30, 'Aiyedaade'),
(575, 30, 'Aiyedire'),
(576, 30, 'Boluwaduro'),
(577, 30, 'Boripe'),
(578, 30, 'Ede North'),
(579, 30, 'Ede South'),
(580, 30, 'Ife Central'),
(581, 30, 'Ife East'),
(582, 30, 'Ife North'),
(583, 30, 'Ife South'),
(584, 30, 'Egbedore'),
(585, 30, 'Ejigbo'),
(586, 30, 'Ifedayo'),
(587, 30, 'Ifelodun'),
(588, 30, 'Ila'),
(589, 30, 'Ilesa East'),
(590, 30, 'Ilesa West'),
(591, 30, 'Irepodun'),
(592, 30, 'Irewole'),
(593, 30, 'Isokan'),
(594, 30, 'Iwo'),
(595, 30, 'Obokun'),
(596, 30, 'Odo Otin'),
(597, 30, 'Ola Oluwa'),
(598, 30, 'Olorunda'),
(599, 30, 'Oriade'),
(600, 30, 'Orolu'),
(601, 30, 'Osogbo'),
(602, 31, 'Akinyele'),
(603, 31, 'Atiba'),
(604, 31, 'Atisbo'),
(605, 31, 'Egbeda'),
(606, 31, 'Ibadan North'),
(607, 31, 'Ibadan North-East'),
(608, 31, 'Ibadan North-West'),
(609, 31, 'Ibadan South-East'),
(610, 31, 'Ibadan South-West'),
(611, 31, 'Ibarapa Central'),
(612, 31, 'Ibarapa East'),
(613, 31, 'Ibarapa North'),
(614, 31, 'Ido'),
(615, 31, 'Irepo'),
(616, 31, 'Iseyin'),
(617, 31, 'Itesiwaju'),
(618, 31, 'Iwajowa'),
(619, 31, 'Kajola'),
(620, 31, 'Lagelu'),
(621, 31, 'Ogbomosho North'),
(622, 31, 'Ogbomosho South'),
(623, 31, 'Ogo Oluwa'),
(624, 31, 'Olorunsogo'),
(625, 31, 'Oluyole'),
(626, 31, 'Ona Ara'),
(627, 31, 'Orelope'),
(628, 31, 'Ori Ire'),
(629, 31, 'Oyo'),
(630, 31, 'Oyo East'),
(631, 31, 'Saki East'),
(632, 31, 'Saki West'),
(633, 31, 'Surulere'),
(634, 32, 'Barkin Ladi'),
(635, 32, 'Bassa'),
(636, 32, 'Jos East'),
(637, 32, 'Jos North'),
(638, 32, 'Jos South'),
(639, 32, 'Kanam'),
(640, 32, 'Kanke'),
(641, 32, 'Langtang South'),
(642, 32, 'Langtang North'),
(643, 32, 'Mangu'),
(644, 32, 'Mikang'),
(645, 32, 'Pankshin'),
(646, 32, 'Qua\'an Pan'),
(647, 32, 'Riyom'),
(648, 32, 'Shendam'),
(649, 32, 'Wase'),
(650, 33, 'Ahoada East'),
(651, 33, 'Ahoada West'),
(652, 33, 'Akuku-Toru'),
(653, 33, 'Andoni'),
(654, 33, 'Asari-Toru'),
(655, 33, 'Bonny'),
(656, 33, 'Degema'),
(657, 33, 'Eleme'),
(658, 33, 'Emuoha'),
(659, 33, 'Etche'),
(660, 33, 'Gokana'),
(661, 33, 'Ikwerre'),
(662, 33, 'Khana'),
(663, 33, 'Obio/Akpor'),
(664, 33, 'Ogba/Egbema/Ndoni'),
(665, 33, 'Ogu/Bolo'),
(666, 33, 'Okrika'),
(667, 33, 'Omuma'),
(668, 33, 'Opobo/Nkoro'),
(669, 33, 'Oyigbo'),
(670, 33, 'Port Harcourt'),
(671, 33, 'Tai'),
(672, 34, 'Bodinga'),
(673, 34, 'Dange Shuni'),
(674, 34, 'Gada'),
(675, 34, 'Goronyo'),
(676, 34, 'Gudu'),
(677, 34, 'Gwadabawa'),
(678, 34, 'Illela'),
(679, 34, 'Isa'),
(680, 34, 'Kebbe'),
(681, 34, 'Kware'),
(682, 34, 'Rabah'),
(683, 34, 'Sabon Birni'),
(684, 34, 'Shagari'),
(685, 34, 'Silame'),
(686, 34, 'Sokoto North'),
(687, 34, 'Sokoto South'),
(688, 34, 'Tambuwal'),
(689, 34, 'Tangaza'),
(690, 34, 'Tureta'),
(691, 34, 'Wamako'),
(692, 34, 'Wurno'),
(693, 34, 'Yabo'),
(694, 35, 'Bali'),
(695, 35, 'Donga'),
(696, 35, 'Gashaka'),
(697, 35, 'Gassol'),
(698, 35, 'Ibi'),
(699, 35, 'Jalingo'),
(700, 35, 'Karim Lamido'),
(701, 35, 'Kumi'),
(702, 35, 'Lau'),
(703, 35, 'Sardauna'),
(704, 35, 'Takum'),
(705, 35, 'Ussa'),
(706, 35, 'Wukari'),
(707, 35, 'Yorro'),
(708, 35, 'Zing'),
(709, 36, 'Bursari'),
(710, 36, 'Damaturu'),
(711, 36, 'Fika'),
(712, 36, 'Fune'),
(713, 36, 'Geidam'),
(714, 36, 'Gujba'),
(715, 36, 'Gulani'),
(716, 36, 'Jakusko'),
(717, 36, 'Karasuwa'),
(718, 36, 'Machina'),
(719, 36, 'Nangere'),
(720, 36, 'Nguru'),
(721, 36, 'Potiskum'),
(722, 36, 'Tarmuwa'),
(723, 36, 'Yunusari'),
(724, 36, 'Yusufari'),
(725, 37, 'Bakura'),
(726, 37, 'Birnin Magaji/Kiyaw'),
(727, 37, 'Bukkuyum'),
(728, 37, 'Bungudu'),
(729, 37, 'Gummi'),
(730, 37, 'Gusau'),
(731, 37, 'Kaura Namoda'),
(732, 37, 'Maradun'),
(733, 37, 'Maru'),
(734, 37, 'Shinkafi'),
(735, 37, 'Talata Mafara'),
(736, 37, 'Chafe'),
(737, 37, 'Zurmi');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `s_email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `msg` text NOT NULL,
  `user_code` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `msg_date` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `num` varchar(10) NOT NULL,
  `msg_code` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `name`, `s_email`, `phone`, `msg`, `user_code`, `email`, `msg_date`, `status`, `num`, `msg_code`) VALUES
(1, 'Administrator007', 'jss1a@yahoo.com', '08062859585', '', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:30:18 PM', '0', '1', ''),
(2, 'Crespy Edo', 'jss1a@yahoo.com', '+2348062165573', '', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:33:52 PM', '0', '1', '905866'),
(3, 'EMETULU@YAHOO.COM', 'jss1a@yahoo.com', '+2348062165573', '', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:37:35 PM', '0', '1', '292859'),
(4, 'Victoria paul', 'jss1a@yahoo.com', '+2348062165573', '', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:41:17 PM', '0', '1', '927739'),
(5, 'sophia@yahoo.com', 'jss1a@yahoo.com', '+2348062165573', '', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:47:13 PM', '0', '1', '553079'),
(6, 'jss1a@yahoo.com', 'jss1a@yahoo.com', '5555555555555', 'g87tfg7g66g', '5c18f0efc8857', 'ciwmnig@gmail.com', '21st  December 2018 06:49:23 PM', '0', '1', '747298'),
(7, 'Aboajah Emmanuel ike', 'jss1a@yahoo.com', '5555555555555', 'fdhdjcjcjccj', '5c18f0efc8857', 'ciwmnig@gmail.com', '22nd  December 2018 07:09:17 AM', '0', '1', '120295'),
(8, 'jss1a@yahoo.com', 'jss1a@yahoo.com', '+2348062165573', 'gfcyygh', '5c18f0efc8857', 'ciwmnig@gmail.com', '22nd  December 2018 07:53:12 AM', '0', '1', '231571');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `type` varchar(50) NOT NULL,
  `purpose` varchar(200) NOT NULL,
  `price` varchar(50) NOT NULL,
  `rooms` varchar(50) NOT NULL,
  `bathrooms` varchar(50) NOT NULL,
  `details` text NOT NULL,
  `address` text NOT NULL,
  `pic` text NOT NULL,
  `latitude` text NOT NULL,
  `longitude` text NOT NULL,
  `state` text NOT NULL,
  `lga` text NOT NULL,
  `fullname` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `occupation` varchar(200) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `ref_id` text NOT NULL,
  `upload_date` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT '0',
  `view` int(11) NOT NULL DEFAULT '0',
  `rent_status` varchar(10) NOT NULL,
  `num` varchar(11) NOT NULL DEFAULT '1',
  `features007` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`id`, `title`, `type`, `purpose`, `price`, `rooms`, `bathrooms`, `details`, `address`, `pic`, `latitude`, `longitude`, `state`, `lga`, `fullname`, `email`, `phone`, `occupation`, `user_id`, `ref_id`, `upload_date`, `status`, `view`, `rent_status`, `num`, `features007`) VALUES
(2, '3 Bedroom Flat', 'Flat', 'Sale', '7500000', '5', '6', 'good', 'lekki', '769-1563888435.jpg', '4444444', '44444', 'lagos', 'Surulere', 'Ken Relocation', '12553@example.com', '09073627352', '', '5', 'WD835951235', '12th  July 2019 01:14:08 PM', '1', 2, '', '1', ''),
(3, '3 Bedroom Flat', 'Flat', 'Sale', '56000000', '4', '4', 'good', 'rgregreg', '964-1563888376.jpg', '4444444', '44444', 'lagos', 'Isiala Ngwa North', 'Ken Relocation', '12553@example.com', '09073627352', '', '5', 'WD795408842', '12th  July 2019 01:20:47 PM', '0', 1, '', '1', ''),
(5, '5 Bedroom Detached Duplex with swimming pool for SALE', 'Flat', 'Sale', '105000000', '5', '4', 'blue', 'lekki', '', '4444444', '3.379205700000057', 'lagos', 'Aba South', 'Ken Relocation', '12553@example.com', '09073627352', '', '5', 'WD317165286', '12th  July 2019 01:32:33 PM', '1', 2, '', '1', ''),
(6, '3 Bedroom Flat at Anthony', 'Flat', 'Rent', '105000000', '2', '2', 'dfbfgbnflbmfrlbntfrbrftngbrtrgnvrt', '9, Isolo streeet', '909-1563556738.jpg', '', '', 'lagos', 'Aba South', 'joyner3', '123@example.com', '5555555555555', '', '4', 'PR125624890', '19th  July 2019 03:45:19 PM', '0', 1, '', '1', ''),
(8, 'sdvdsvdsvdsds', 'Flat', 'Sale', '56000000', '4', '4', 'â€œDon&#39;t let perfection become procrastination. Do it now.â€\r\n\r\n\r\n\r\nâ€œTo be beautiful means to be yourself. You don&#39;t need to\r\nbe accepted by others. You need to be yourself.â€\r\n\r\njss1 peal \r\njss3 emerade', '9, Isolo streeet', '', '6.5243793', '3.379205700000057', 'lagos', 'Isiala Ngwa North', 'gugdvdfhvdfs', '12553@example.com', '09073627352', '', '5', 'PR669953981', '22nd  July 2019 06:14:14 PM', '0', 0, '', '1', ''),
(9, '3 Bedroom Flat at Anthony', 'House', 'Rent', '90000000', '5', '4', 'dkjvbdno dcmd;cnjd', 'rgregreg', '317-1563817630.jpg', '6.513510300000001', '3.379205700000057', 'lagos', 'Aba South', 'gugdvdfhvdfs', '12553@example.com', '09073627352', '', '5', 'PR533605485', '22nd  July 2019 06:45:53 PM', '1', 1, '', '1', ''),
(10, 'Frontier Estate (Land For Sale)', 'House', 'Rent', '90000000', '6', '8', 'â€œDon&#39;t let perfection become procrastination. Do it now.â€\r\n\r\n\r\n\r\nâ€œTo be beautiful means to be yourself. You don&#39;t need to\r\nbe accepted by others. You need to be yourself.â€\r\n\r\njss1 peal \r\njss3 emerade', 'dcvdcd', '131-1563819216.jpg', '6.5243793', '44444', 'lagos', 'Aba South', 'gugdvdfhvdfs', '12553@example.com', '09073627352', '', '5', 'PR829903938', '22nd  July 2019 07:08:57 PM', '0', 0, '', '1', ''),
(14, 'wandy', 'Bungalow', 'Rent', '90000000', '3', '4', '', 'rgregreg', '243-1563877618.jpg', '6.513510300000001', '44444', 'lagos', 'Aba South', 'gugdvdfhvdfs', '12553@example.com', '09073627352', '', '5', 'PR269679830', '23rd  July 2019 11:21:29 AM', '1', 3, '', '1', '');

-- --------------------------------------------------------

--
-- Table structure for table `pro_img`
--

CREATE TABLE `pro_img` (
  `id` int(11) NOT NULL,
  `pic` text NOT NULL,
  `ref_id` text NOT NULL,
  `user_id` text NOT NULL,
  `num` varchar(10) NOT NULL DEFAULT '1',
  `upload_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pro_img`
--

INSERT INTO `pro_img` (`id`, `pic`, `ref_id`, `user_id`, `num`, `upload_date`) VALUES
(12, '548-1563547753.png', 'PR125624890', '4', '1', '19th  July 2019 03:49:13 PM'),
(13, '425-1563547753.png', 'PR125624890', '4', '1', '19th  July 2019 03:49:13 PM'),
(14, '468-1563547754.png', 'PR125624890', '4', '1', '19th  July 2019 03:49:14 PM'),
(15, '859-1563547754.png', 'PR125624890', '4', '1', '19th  July 2019 03:49:14 PM'),
(16, '387-1563547754.png', 'PR125624890', '4', '1', '19th  July 2019 03:49:14 PM'),
(17, '185-1563556738.jpg', 'PR125624890', '4', '1', '19th  July 2019 06:18:58 PM'),
(18, '909-1563556738.jpg', 'PR125624890', '4', '1', '19th  July 2019 06:18:58 PM'),
(23, '723-1563586996.jpg', 'PR125624890', '4', '1', '20th  July 2019 02:43:16 AM'),
(24, '110-1563586996.jpg', 'PR125624890', '4', '1', '20th  July 2019 02:43:16 AM'),
(25, '732-1563817606.jpg', 'PR533605485', '5', '1', '22nd  July 2019 06:46:46 PM'),
(26, '453-1563817629.jpg', 'PR533605485', '5', '1', '22nd  July 2019 06:47:10 PM'),
(27, '317-1563817630.jpg', 'PR533605485', '5', '1', '22nd  July 2019 06:47:10 PM'),
(28, '697-1563817630.jpg', 'PR533605485', '5', '1', '22nd  July 2019 06:47:10 PM'),
(29, '850-1563817630.jpg', 'PR533605485', '5', '1', '22nd  July 2019 06:47:10 PM'),
(30, '539-1563819216.jpg', 'PR829903938', '5', '1', '22nd  July 2019 07:13:36 PM'),
(31, '153-1563819216.jpg', 'PR829903938', '5', '1', '22nd  July 2019 07:13:36 PM'),
(32, '237-1563819216.jpg', 'PR829903938', '5', '1', '22nd  July 2019 07:13:36 PM'),
(33, '131-1563819216.jpg', 'PR829903938', '5', '1', '22nd  July 2019 07:13:36 PM'),
(34, '230-1563819216.jpg', 'PR829903938', '5', '1', '22nd  July 2019 07:13:36 PM'),
(35, '986-1563819217.jpg', 'PR829903938', '5', '1', '22nd  July 2019 07:13:37 PM'),
(36, '469-1563819217.jpg', 'PR829903938', '5', '1', '22nd  July 2019 07:13:37 PM'),
(37, '463-1563819217.jpg', 'PR829903938', '5', '1', '22nd  July 2019 07:13:37 PM'),
(38, '769-1563819217.jpg', 'PR829903938', '5', '1', '22nd  July 2019 07:13:37 PM'),
(39, '899-1563819259.jpg', 'PR829903938', '5', '1', '22nd  July 2019 07:14:19 PM'),
(40, '563-1563822230.jpg', 'PR829903938', '5', '1', '22nd  July 2019 08:03:51 PM'),
(41, '980-1563822231.jpg', 'PR829903938', '5', '1', '22nd  July 2019 08:03:51 PM'),
(42, '380-1563822231.jpg', 'PR829903938', '5', '1', '22nd  July 2019 08:03:51 PM'),
(43, '720-1563826293.jpg', 'PR829903938', '5', '1', '22nd  July 2019 09:11:34 PM'),
(44, '479-1563828164.jpg', '<br', '5', '1', '22nd  July 2019 09:42:44 PM'),
(45, '635-1563828165.jpg', '<br', '5', '1', '22nd  July 2019 09:42:45 PM'),
(46, '486-1563828165.jpg', '<br', '5', '1', '22nd  July 2019 09:42:45 PM'),
(47, '915-1563829731.jpg', '<br', '5', '1', '22nd  July 2019 10:08:51 PM'),
(48, '121-1563829912.jpg', '<br', '5', '1', '22nd  July 2019 10:11:53 PM'),
(49, '676-1563829913.jpg', '<br', '5', '1', '22nd  July 2019 10:11:53 PM'),
(50, '184-1563829913.jpg', '<br', '5', '1', '22nd  July 2019 10:11:54 PM'),
(51, '601-1563830964.jpg', '<br', '5', '1', '22nd  July 2019 10:29:24 PM'),
(52, '579-1563867103.jpg', '<br', '5', '1', '23rd  July 2019 08:31:43 AM'),
(53, '674-1563867204.jpg', '<br', '5', '1', '23rd  July 2019 08:33:24 AM'),
(54, '997-1563877459.jpg', 'PR269679830', '5', '1', '23rd  July 2019 11:24:19 AM'),
(55, '958-1563877459.jpg', 'PR269679830', '5', '1', '23rd  July 2019 11:24:19 AM'),
(56, '813-1563877459.jpg', 'PR269679830', '5', '1', '23rd  July 2019 11:24:19 AM'),
(57, '847-1563877460.jpg', 'PR269679830', '5', '1', '23rd  July 2019 11:24:20 AM'),
(58, '231-1563877579.jpg', 'PR269679830', '5', '1', '23rd  July 2019 11:26:19 AM'),
(59, '428-1563877580.jpg', 'PR269679830', '5', '1', '23rd  July 2019 11:26:20 AM'),
(60, '653-1563877580.jpg', 'PR269679830', '5', '1', '23rd  July 2019 11:26:20 AM'),
(61, '404-1563877581.jpg', 'PR269679830', '5', '1', '23rd  July 2019 11:26:21 AM'),
(62, '243-1563877618.jpg', 'PR269679830', '5', '1', '23rd  July 2019 11:26:58 AM'),
(63, '780-1563888376.jpg', 'WD795408842', '5', '1', '23rd  July 2019 02:26:16 PM'),
(64, '964-1563888376.jpg', 'WD795408842', '5', '1', '23rd  July 2019 02:26:16 PM'),
(65, '568-1563888376.jpg', 'WD795408842', '5', '1', '23rd  July 2019 02:26:16 PM'),
(66, '769-1563888435.jpg', 'WD835951235', '5', '1', '23rd  July 2019 02:27:15 PM'),
(67, '842-1563888435.jpg', 'WD835951235', '5', '1', '23rd  July 2019 02:27:15 PM'),
(68, '562-1563888436.jpg', 'WD835951235', '5', '1', '23rd  July 2019 02:27:16 PM');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `state_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`state_id`, `name`) VALUES
(1, 'Abia '),
(2, 'Adamawa '),
(3, 'Akwa Ibom '),
(4, 'Anambra '),
(5, 'Bauchi '),
(6, 'Bayelsa '),
(7, 'Benue '),
(8, 'Borno '),
(9, 'Cross River '),
(10, 'Delta '),
(11, 'Ebonyi '),
(12, 'Edo '),
(13, 'Ekiti '),
(14, 'Enugu '),
(15, 'FCT'),
(16, 'Gombe '),
(17, 'Imo '),
(18, 'Jigawa '),
(19, 'Kaduna '),
(20, 'Kano '),
(21, 'Katsina '),
(22, 'Kebbi '),
(23, 'Kogi '),
(24, 'Kwara '),
(25, 'Lagos '),
(26, 'Nasarawa '),
(27, 'Niger '),
(28, 'Ogun '),
(29, 'Ondo '),
(30, 'Osun '),
(31, 'Oyo '),
(32, 'Plateau '),
(33, 'Rivers '),
(34, 'Sokoto '),
(35, 'Taraba '),
(36, 'Yobe '),
(37, 'Zamfara ');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `password` text NOT NULL,
  `location` text NOT NULL,
  `occupation` text NOT NULL,
  `fb_name` text NOT NULL,
  `tw_name` text NOT NULL,
  `int_name` text NOT NULL,
  `gender` varchar(20) NOT NULL,
  `about` text NOT NULL,
  `image` text NOT NULL,
  `ImageUrl` text NOT NULL,
  `fbpic` text NOT NULL,
  `fbid` text NOT NULL,
  `num` varchar(10) NOT NULL,
  `user_code` text NOT NULL,
  `google_id` text NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT '1',
  `pass_status` varchar(10) NOT NULL,
  `reg_date` varchar(100) NOT NULL,
  `reg_time` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `sms_code` varchar(20) NOT NULL,
  `user_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `location`, `occupation`, `fb_name`, `tw_name`, `int_name`, `gender`, `about`, `image`, `ImageUrl`, `fbpic`, `fbid`, `num`, `user_code`, `google_id`, `status`, `pass_status`, `reg_date`, `reg_time`, `type`, `sms_code`, `user_status`) VALUES
(4, 'joyner3', '123@example.com', '5555555555555', '$2y$10$WjLI9.F.bh375vSXK0XxpunE3ILrvmhAChfxqe77cUqt7b74rt0Ry', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', 'Agent', '', ''),
(5, 'Ken pass', '12553@example.com', '09073627352', '$2y$10$DX5Ip0AJjc5jBM9/IjvWyOmzxAgc9Z31.kLOFJPLMpaZjEqRQiCHW', '', '', '', '', '', '', '', '537-1564301977.jpg', '', '', '', '', '', '', '1', '', '', '', 'Agent', '', ''),
(6, 'mike good', 'j@me.com', '98087989899', '$2y$10$kqVuOgh78ckjMfFBa/SIIu..b1oo3GyqQwc1McrAnUUsv461FH2AG', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', 'Agent', '', ''),
(7, 'Abigail Udeme Jackson', 'jive@yahoo.com', '5555555555555', '$2y$10$Ec2uqcUOonRQBzw9ZaIqee1lLkJuLAVaXHZ4ObJNttGuRo.yCIdX2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', 'Agent', '', ''),
(11, 'Paul Damilola', 'dami@me.com', '090736273567', '$2y$10$sGw4yjNAJ.iveFj4JGVMe.VblPeJPFKOKV8DvYm1qAmHOUlNjlx/m', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', 'User', '', ''),
(12, 'Aboajah Emmanuel', 'emma22@me.com', '090756343', '$2y$10$ib.i/BU0NQtvGZssOn6unuE8T8tHrbwMeRPCbtVyyxZE9bVCAd55K', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '', '1st  August 2019 03:12:08 PM', '', 'User', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adm_message`
--
ALTER TABLE `adm_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `imgtest`
--
ALTER TABLE `imgtest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locals`
--
ALTER TABLE `locals`
  ADD PRIMARY KEY (`local_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_img`
--
ALTER TABLE `pro_img`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `adm_message`
--
ALTER TABLE `adm_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `imgtest`
--
ALTER TABLE `imgtest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `locals`
--
ALTER TABLE `locals`
  MODIFY `local_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=738;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `pro_img`
--
ALTER TABLE `pro_img`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
